﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AntimatterTestGenerator
{
    class Program
    {
        class Point
        {
            public int X { get; set; }
            public int Y { get; set; }

            public Point(int x, int y)
            {
                this.X = x;
                this.Y = y;
            }

            public static Point operator +(Point a, Point b)
            {
                return new Point(a.X + b.X, a.Y + b.Y);
            }

            public static Point operator *(Point a, int scale)
            {
                return new Point(a.X * scale, a.Y * scale);
            }

            public static Point operator -(Point a, Point b)
            {
                return new Point(a.X - b.X, a.Y - b.Y);
            }

            public override int GetHashCode()
            {
                return this.X.GetHashCode() + this.Y.GetHashCode() * 31;
            }

            // override object.Equals
            public override bool Equals(object obj)
            {
                if (obj == null || GetType() != obj.GetType())
                {
                    return false;
                }

                Point other = (Point)obj;
                return this.X.Equals(other.X) && this.Y.Equals(other.Y);
            }

            public override string ToString()
            {
                return X + " " + Y;
            }
        }

        class ParticleSpaceTimeCoords
        {
            public Point SpatialCoords { get; private set; }
            public int Time { get; private set; }
            public bool Matter { get; private set; }

            public ParticleSpaceTimeCoords(bool isMatter, int x, int y, int time) : this(isMatter, new Point(x, y), time) { }

            public ParticleSpaceTimeCoords(bool isMatter, Point spatialCoords, int time)
            {
                this.Matter = isMatter;
                this.SpatialCoords = spatialCoords;
                this.Time = time;
            }

            // override object.Equals
            public override bool Equals(object obj)
            {
                if (obj == null || GetType() != obj.GetType())
                {
                    return false;
                }

                ParticleSpaceTimeCoords other = (ParticleSpaceTimeCoords)obj;

                return this.Matter.Equals(other.Matter) && this.SpatialCoords.Equals(other.SpatialCoords) && this.Time.Equals(other.Time);
            }

            public override int GetHashCode()
            {
                return (Matter ? 1 : -1) * this.SpatialCoords.GetHashCode() + this.Time * 71;
            }

            public ParticleSpaceTimeCoords GetAntiCoords()
            {
                return new ParticleSpaceTimeCoords(!Matter, SpatialCoords, Time);
            }
        }

        class Particle
        {
            public bool Matter { get; private set; }
            public Point Position { get; private set; }
            public Point Speed { get; private set; }
            public int Lifetime { get; private set; }

            public Particle(bool isMatter, int x, int y, int speedX, int speedY, int lifetime) : this(isMatter, new Point(x, y), new Point(speedX, speedY), lifetime) {}

            public Particle(bool isMatter, Point position, Point speed, int lifetime)
            {
                this.Matter = isMatter;
                this.Position = position;
                this.Speed = speed;
                this.Lifetime = lifetime;
            }

            public override string ToString()
            {
                return (Matter ? "m" : "a") + " " + Position.ToString() + " " + Speed.ToString() + " " + Lifetime;
            }
        }

        static Random random = new Random();

        const int MaxCoord = 65535;
        const int MaxSpeed = 10;
        const int MaxLifetime = 2000;

        static void Main(string[] args)
        {
            GenerateTest("test.001", totalTime: 8, collisionsCount: 3, maxParticlesPerCollision: 2, exitedCount: 0, decayedCount: 0, survivingMatterCount: 5, survivingAntimatterCount: 4);
            GenerateTest("test.002", totalTime: 3, collisionsCount: 0, maxParticlesPerCollision: 0, exitedCount: 1, decayedCount: 0, survivingMatterCount: 1, survivingAntimatterCount: 0);
            GenerateTest("test.003", totalTime: 6, collisionsCount: 0, maxParticlesPerCollision: 0, exitedCount: 0, decayedCount: 1, survivingMatterCount: 3, survivingAntimatterCount: 8);
            GenerateTest("test.004", totalTime: 10, collisionsCount: 10, maxParticlesPerCollision: 8, exitedCount: 5, decayedCount: 8, survivingMatterCount: 12, survivingAntimatterCount: 42);
            GenerateTest("test.005", totalTime: 10, collisionsCount: 2, maxParticlesPerCollision: 10, exitedCount: 20, decayedCount: 17, survivingMatterCount: 19, survivingAntimatterCount: 21);

            GenerateTest("test.006", totalTime: 800, collisionsCount: 30, maxParticlesPerCollision: 2, exitedCount: 0, decayedCount: 0, survivingMatterCount: 370, survivingAntimatterCount: 450);
            GenerateTest("test.007", totalTime: 300, collisionsCount: 1, maxParticlesPerCollision: 3, exitedCount: 10, decayedCount: 30, survivingMatterCount: 5, survivingAntimatterCount: 3);
            GenerateTest("test.008", totalTime: 600, collisionsCount: 5, maxParticlesPerCollision: 2, exitedCount: 43, decayedCount: 100, survivingMatterCount: 22, survivingAntimatterCount: 26);
            GenerateTest("test.009", totalTime: 1000, collisionsCount: 20, maxParticlesPerCollision: 10, exitedCount: 200, decayedCount: 170, survivingMatterCount: 190, survivingAntimatterCount: 210);
            GenerateTest("test.010", totalTime: 1000, collisionsCount: 100, maxParticlesPerCollision: 7, exitedCount: 100, decayedCount: 100, survivingMatterCount: 120, survivingAntimatterCount: 420);
        }

        static void GenerateTest(string testName, int totalTime, int collisionsCount, int maxParticlesPerCollision, int exitedCount, int decayedCount, int survivingMatterCount, int survivingAntimatterCount)
        {
            List<Particle> particles = new List<Particle>();

            HashSet<ParticleSpaceTimeCoords> occupied = new HashSet<ParticleSpaceTimeCoords>();
            List<int> collisionTimes = totalTime > 1 ? random.NextIncreasingOrEqualInRange(collisionsCount, new Pair<int>(1, totalTime - 1)) : new List<int>();
            int destroyedInCollisions = 0;

            SortedDictionary<int, List<List<Particle>>> collidedByTime = new SortedDictionary<int, List<List<Particle>>>();

            foreach (var time in collisionTimes)
            {
                List<Particle> newParticles = GenerateCollisionParticles(time, random.Next(2, maxParticlesPerCollision + 1), occupied);
                particles.AddRange(newParticles);
                destroyedInCollisions += newParticles.Count;

                if (!collidedByTime.ContainsKey(time))
                {
                    collidedByTime.Add(time, new List<List<Particle>>());
                }
                collidedByTime[time].Add(newParticles);
            }

            for (int i = 0; i < exitedCount; i++)
            {
                particles.Add(GenerateExitedParticle(totalTime, occupied));
            }

            for (int i = 0; i < decayedCount; i++)
            {
                particles.Add(GenerateDecayedParticle(totalTime, occupied));
            }

            for (int i = 0; i < survivingMatterCount; i++)
            {
                particles.Add(GenerateSurvivingParticle(true, totalTime, occupied));
            }

            for (int i = 0; i < survivingAntimatterCount; i++)
            {
                particles.Add(GenerateSurvivingParticle(false, totalTime, occupied));
            }

            random.NextShuffle(particles);

            List<String> inputLines = new List<string>();
            inputLines.Add(particles.Count.ToString());
            foreach (var p in particles)
            {
                inputLines.Add(p.ToString());
            }
            inputLines.Add(totalTime.ToString());

            File.WriteAllLines(testName + ".in.txt", inputLines);
            File.WriteAllLines(testName + ".out.txt", new List<string>() { survivingMatterCount + " " + survivingAntimatterCount, destroyedInCollisions.ToString() });

            File.WriteAllLines("debug-" + testName + ".info.txt", collidedByTime.Select(e => {
                List<string> groups = new List<string>();
                foreach (var group in e.Value)
                {
                    groups.Add("- " + string.Join(Environment.NewLine + "- ", group));
                }

                return e.Key + Environment.NewLine + string.Join(Environment.NewLine + "----" + Environment.NewLine, groups);
            }));
        }

        private static Particle GenerateSurvivingParticle(bool isMatter, int totalTime, HashSet<ParticleSpaceTimeCoords> occupied)
        {
            Particle particle = TryGenerateParticleReaching(GenerateSpatialCoords(), totalTime, isMatter, random.Next(MaxLifetime - totalTime));
            while (particle == null || !TryAddTrajectory(occupied, GenerateParticleTrajectory(particle, particle.Lifetime)))
            {
                particle = TryGenerateParticleReaching(GenerateSpatialCoords(), totalTime, isMatter, random.Next(MaxLifetime - totalTime));
            }

            return particle;
        }

        private static Particle GenerateDecayedParticle(int totalTime, HashSet<ParticleSpaceTimeCoords> occupied)
        {
            // NOTE: -1 "additionalLifetime", because GenerateParticleReaching generates a particle that has 1 lifetime remaining when reaching the point
            Particle particle = TryGenerateParticleReaching(GenerateSpatialCoords(), totalTime, random.NextBool(), -1);
            while (particle == null || !TryAddTrajectory(occupied, GenerateParticleTrajectory(particle, particle.Lifetime)))
            {
                particle = TryGenerateParticleReaching(GenerateSpatialCoords(), totalTime, random.NextBool(), -1);
            }

            return particle;
        }

        private static Particle GenerateExitedParticle(int totalTime, HashSet<ParticleSpaceTimeCoords> occupied)
        {
            Point center = new Point(MaxCoord / 2, MaxCoord / 2);
            Point minOffset = new Point(MaxCoord / 2 + 10, MaxCoord / 2 + 10);
            Point maxOffset = new Point(MaxCoord / 2 + 100, MaxCoord / 2 + 100);

            int reachTime = random.Next(1, totalTime);
            Point offset = new Point(random.Next(minOffset.X, maxOffset.X + 1), random.Next(minOffset.Y, maxOffset.Y + 1));
            Particle particle = TryGenerateParticleReaching(center + offset, reachTime, random.NextBool(), random.Next(MaxLifetime - totalTime));
            while (particle == null || !TryAddTrajectory(occupied, GenerateParticleTrajectory(particle, particle.Lifetime))) {
                reachTime = random.Next(1, totalTime + 1);
                offset = new Point(random.Next(minOffset.X, maxOffset.X + 1), random.Next(minOffset.Y, maxOffset.Y + 1));
                particle = TryGenerateParticleReaching(center + offset, reachTime, random.NextBool(), random.Next(MaxLifetime - totalTime));
            }
            return particle;
        }

        private static List<Particle> GenerateCollisionParticles(int time, int newParticlesCount, HashSet<ParticleSpaceTimeCoords> occupied)
        {
            List<Particle> newParticles = new List<Particle>();

            ParticleSpaceTimeCoords collision = new ParticleSpaceTimeCoords(true, GenerateSpatialCoords(), time);
            while (occupied.Contains(collision) || occupied.Contains(collision.GetAntiCoords()))
            {
                collision = new ParticleSpaceTimeCoords(true, GenerateSpatialCoords(), time);
            }
            // add the collision point coords for both antimatter and matter, so that nothing tries to occupy this spacetime
            occupied.Add(collision);
            occupied.Add(collision.GetAntiCoords());

            while (newParticles.Count < newParticlesCount)
            {
                bool isMatter = newParticles.Count == 0 ? true : (newParticles.Count == 1 ? false : random.NextBool());

                Particle p = GenerateParticleReaching(collision.SpatialCoords, time, isMatter, random.Next(MaxLifetime - time));
                // NOTE: all collision trajectories end at time, so we avoid checking that last position
                if (TryAddTrajectory(occupied, GenerateParticleTrajectory(p, time - 1)))
                {
                    newParticles.Add(p);
                }
            }

            return newParticles;
        }

        private static bool TryAddTrajectory(HashSet<ParticleSpaceTimeCoords> occupied, ParticleSpaceTimeCoords point)
        {
            return TryAddTrajectory(occupied, new List<ParticleSpaceTimeCoords>() { point });
        }

        private static bool TryAddTrajectory(HashSet<ParticleSpaceTimeCoords> occupied, List<ParticleSpaceTimeCoords> points)
        {
            foreach (var p in points)
            {
                if (occupied.Contains(p.GetAntiCoords()))
                {
                    return false;
                }
            }

            foreach (var p in points)
            {
                occupied.Add(p);
            }

            return true;
        }

        private static Particle GenerateParticleReaching(Point target, int timeToReach, bool matter, int additionalLifetime)
        {
            Particle p = TryGenerateParticleReaching(target, timeToReach, matter, additionalLifetime);
            while (p == null) {
                p = TryGenerateParticleReaching(target, timeToReach, matter, additionalLifetime);
            }

            return p;
        }

        private static Particle TryGenerateParticleReaching(Point target, int timeToReach, bool matter, int additionalLifetime)
        {
            Point speed = GenerateSpeed();
            Point origin = target + (speed * timeToReach);
            if (!IsOutside(origin))
            {
                return new Particle(matter, origin, speed * -1, timeToReach + 1 + additionalLifetime);
            }

            return null;
        }

        private static Point GenerateSpatialCoords()
        {
            return new Point(random.Next(0, MaxCoord), random.Next(0, MaxCoord));
        }

        private static Point GenerateSpeed()
        {
            return new Point(random.Next(-MaxSpeed, MaxSpeed + 1), random.Next(-MaxSpeed, MaxSpeed + 1));
        }

        private static List<ParticleSpaceTimeCoords> GenerateParticleTrajectory(Particle p, int time)
        {
            List<ParticleSpaceTimeCoords> trajectory = new List<ParticleSpaceTimeCoords>();
            int currentTime = 0; // all particles start simultaneously
            trajectory.Add(new ParticleSpaceTimeCoords(p.Matter, p.Position, 0));

            for (currentTime = 1; currentTime <= Math.Min(time, p.Lifetime - 1); currentTime++)
            {
                trajectory.Add(new ParticleSpaceTimeCoords(p.Matter, p.Position + p.Speed * currentTime, currentTime));
            }

            return trajectory;
        }

        static bool IsOutside(Point p)
        {
            return p.X < 0 || p.Y < 0 || p.X > MaxCoord || p.Y > MaxCoord;
        }
    }

    struct Pair<T>
    {
        public T First { get; set; }
        public T Second { get; set; }
        public Pair(T first, T second)
        {
            this.First = first;
            this.Second = second;
        }
    }

    static class RandomExtensions
    {
        public static List<int> NextIncreasingOrEqualInRange(this Random r, int length, Pair<int> rangeInclusive)
        {
            List<int> values = new List<int>();
            while (values.Count < length)
            {
                values.Add(r.Next(values.Count > 0 ? values[values.Count - 1] : rangeInclusive.First, rangeInclusive.Second + 1));
            }

            return new List<int>(values);
        }

        public static List<int> NextStrictlyIncreasingInRange(this Random r, int length, Pair<int> rangeInclusive)
        {
            int rangeElementsCount = (rangeInclusive.Second - rangeInclusive.First) + 1;
            if (rangeElementsCount < length)
            {
                throw new ArgumentException("rangeInclusive does not contain enough values to generate required length");
            }

            SortedSet<int> values = new SortedSet<int>();
            while (values.Count < length)
            {
                values.Add(r.Next(rangeInclusive.First, rangeInclusive.Second + 1));
            }

            return new List<int>(values);
        }

        public static void NextShuffle<T>(this Random r, List<T> list)
        {
            for (int repeats = 0; repeats < 10; repeats++)
            {
                for (int i = 0; i < list.Count; i++)
                {
                    int otherInd = r.Next(0, list.Count);
                    var swap = list[i];
                    list[i] = list[otherInd];
                    list[otherInd] = swap;
                }
            }
        }

        public static int NextIndex<T>(this Random r, ICollection<T> range)
        {
            return r.Next(0, range.Count);
        }

        public static T NextFrom<T>(this Random r, List<T> from)
        {
            return from[NextIndex(r, from)];
        }

        public static List<int> NextIntegersFrom(this Random r, int count, List<int> from)
        {
            List<int> integers = new List<int>();

            while (integers.Count < count)
            {
                integers.Add(NextFrom(r, from));
            }

            return integers;
        }

        public static List<int> NextIntegers(this Random r, int count)
        {
            return NextIntegersExcluding(r, count, new HashSet<int>());
        }

        public static List<int> NextIntegersExcluding(this Random r, int count, HashSet<int> excluded)
        {
            List<int> integers = new List<int>();

            while (integers.Count < count)
            {
                integers.Add(NextExcluding(r, excluded));
            }

            return integers;
        }

        public static int NextExcluding(this Random r, HashSet<int> excluded)
        {
            int value = r.Next();
            while (excluded.Contains(value))
            {
                value = r.Next();
            }

            return value;
        }

        public static bool NextBool(this Random r)
        {
            return (r.Next() & 1) != 0;
        }
    }
}
