﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SecretTestGenerator
{
    class Program
    {
        static Random r = new Random();

        static void Main(string[] args)
        {
            GenerateTest("test.001", 'F', "She sells sea shells on the sea shore");
            GenerateTest("test.002", 'Y', "She !s!el  ls sea sh+__+-ells on the,sea,, ,shore");
            GenerateTest("test.003", 17, "S h e   s e l l s  s e a   s h e l l s  o n   t h e   se a   s h o r e ");
            GenerateTest("test.004", 'v', "Roses are red, violets are blue, unexpected '{' on line thirty-two");
            GenerateTest("test.005", 'H', "'$!^^#!$$^_)&*()#)()+!_)!$$$!_*#%)!%T#^+)||}{{}@#%}!@{%!@%|");

            GenerateTest("test.006", 'w', "abcdefghijklmnopqrstuvwxyz");
            GenerateTest("test.007", 'U', "!#^%)*&@)*^!)^ the quick brown fox jumps over the lazy dog");
            GenerateTest("test.008", 'Q', "Be sure to get what you like, or else you'll be forced to like what you get");
            GenerateTest("test.009", 12, "You can hack some of the tests some of the time, or one of the tests all of the time, but you can't fool all of the tests all of the time");
            GenerateTest("test.010", 503, "There are old pilots and there are bold pilots, but there are no old bold pilots");
        }

        private static void GenerateTest(string testName, int result, string text)
        {
            int sum = 0;
            StringBuilder inputText = new StringBuilder(text);
            while (sum != result)
            {
                int digit = r.Next(0, 10);
                if (sum + digit > result)
                {
                    digit = result - sum;
                }

                inputText.Insert(r.Next(0, text.Length + 1), digit + "");
                sum += digit;
            }

            System.IO.File.WriteAllText(testName + ".in.txt", inputText.ToString() + ".");
            System.IO.File.WriteAllText(testName + ".out.txt", (char.IsLetter((char)result) && result < 128) ? ((char)result) + "" : result + "");
        }
    }

    static class RandomExtensions
    {
        public static void NextShuffle<T>(this Random r, List<T> list)
        {
            for (int repeats = 0; repeats < 10; repeats++)
            {
                for (int i = 0; i < list.Count; i++)
                {
                    int otherInd = r.Next(0, list.Count);
                    var swap = list[i];
                    list[i] = list[otherInd];
                    list[otherInd] = swap;
                }
            }
        }

        public static int NextIndex<T>(this Random r, ICollection<T> range)
        {
            return r.Next(0, range.Count);
        }

        public static T NextItem<T>(this Random r, IList<T> range)
        {
            return range[r.Next(0, range.Count)];
        }

        public static string NextWord(this Random r, int length)
        {
            char[] word = new char[length];

            for (int i = 0; i < word.Length; i++)
            {
                word[i] = (char)(r.Next() % 2 == 0 ? r.Next('A', 'Z' + 1) : r.Next('a', 'z' + 1));
            }

            return new string(word);
        }

        public static string NextText(this Random r, int length)
        {
            char[] text = new char[length];
            for (int i = 0; i < text.Length; i++)
            {
                text[i] = i < length - 1 && i != 0 && char.IsLetter(text[i - 1]) && NextChance(r, 0.1) ?
                    ' ' : (char)r.Next('a', 'z' + 1);
            }

            return string.Join("", text);
        }

        public static string NextWordOrNumber(this Random r, int length)
        {
            char[] word = new char[length];

            for (int i = 0; i < word.Length; i++)
            {
                word[i] = (char)(r.Next() % 2 == 0 ?
                    (r.Next() % 2 == 0 ? r.Next('A', 'Z' + 1) : r.Next('a', 'z' + 1))
                    : (r.Next('0', '9' + 1)));
            }

            return new string(word);
        }

        public static string NextReplaceN(this Random r, string s, char replaceChar, int count)
        {
            StringBuilder result = new StringBuilder(s);

            for (int i = 0; i < count; i++)
            {
                result[r.Next(0, s.Length)] = replaceChar;
            }

            return result.ToString();
        }

        public static List<double> NextUniqueDoubles(this Random r, int count, double min = -double.MaxValue / 2, double max = double.MaxValue / 2, int digitsAfterPoint = 2)
        {
            HashSet<double> unique = new HashSet<double>();

            double range = max - min;
            while (unique.Count < count)
            {
                double number = double.Parse((min + range * r.NextDouble()).ToString("#." + new string('#', digitsAfterPoint)));
                unique.Add(number);
            }

            return unique.ToList();
        }

        public static bool NextChance(this Random r, double odds0To1)
        {
            return r.NextDouble() < odds0To1;
        }

        public static List<T> NextUniqueSubset<T>(this Random r, ISet<T> set)
        {
            int count = r.Next(1, set.Count + 1);

            List<T> list = new List<T>(set);
            r.NextShuffle(list);

            return list.GetRange(0, count);
        }
    }
}
