﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodeTestGenerator
{
    class Program
    {
        static Random random = new Random();

        static void Main(string[] args)
        {
            GenerateTest(name: "test.001", partsCount: 5, maxPartLength: 3, totalSeparators: 4, repeatedValuesInPart: false, successSearches: 2, zeroSearches: 1, separatorSearches: 0);
            GenerateTest(name: "test.002", partsCount: 10, maxPartLength: 3, totalSeparators: 20, repeatedValuesInPart: false, successSearches: 20, zeroSearches: 10, separatorSearches: 0);
            GenerateTest(name: "test.003", partsCount: 20, maxPartLength: 10, totalSeparators: 20, repeatedValuesInPart: false, successSearches: 50, zeroSearches: 10, separatorSearches: 0);
            GenerateTest(name: "test.004", partsCount: 30, maxPartLength: 10, totalSeparators: 30, repeatedValuesInPart: true, successSearches: 20, zeroSearches: 40, separatorSearches: 0);
            GenerateTest(name: "test.005", partsCount: 50, maxPartLength: 10, totalSeparators: 100, repeatedValuesInPart: true, successSearches: 10, zeroSearches: 10, separatorSearches: 5);

            GenerateTest(name: "test.006", partsCount: 500, maxPartLength: 30, totalSeparators: 500, repeatedValuesInPart: false, successSearches: 20000, zeroSearches: 10000, separatorSearches: 0);
            GenerateTest(name: "test.007", partsCount: 100, maxPartLength: 50, totalSeparators: 500, repeatedValuesInPart: false, successSearches: 20000, zeroSearches: 10000, separatorSearches: 10000);
            GenerateTest(name: "test.008", partsCount: 400, maxPartLength: 40, totalSeparators: 500, repeatedValuesInPart: false, successSearches: 40000, zeroSearches: 100, separatorSearches: 100);
            GenerateTest(name: "test.009", partsCount: 450, maxPartLength: 30, totalSeparators: 5000, repeatedValuesInPart: true, successSearches: 20000, zeroSearches: 4000, separatorSearches: 5000);
            GenerateTest(name: "test.010", partsCount: 500, maxPartLength: 50, totalSeparators: 5000, repeatedValuesInPart: true, successSearches: 20000, zeroSearches: 19500, separatorSearches: 500);
        }

        static void GenerateTest(string name, int partsCount, int maxPartLength, int totalSeparators, bool repeatedValuesInPart, int successSearches, int zeroSearches, int separatorSearches)
        {
            if (totalSeparators < partsCount - 1)
            {
                throw new ArgumentException("totalSeparators must be such that totalSeparators >= partsCount - 1");
            }

            List<List<int>> parts = new List<List<int>>();
            HashSet<int> allValues = new HashSet<int>();

            List<int> separators = random.NextIntegersExcluding(totalSeparators, new HashSet<int>() { 0 });
            HashSet<int> separatorsSet = new HashSet<int>(separators);

            while (parts.Count < partsCount)
            {
                List<int> part = random.NextIntegersExcluding(random.Next(1, maxPartLength + 1), separatorsSet);
                for (int i = 0; i < part.Count; i++)
                {
                    part[i] %= random.Next(1, (partsCount)) + 1;
                }

                if (!repeatedValuesInPart)
                {
                    part = new HashSet<int>(part).ToList();
                }

                parts.Add(part);
                allValues.UnionWith(new HashSet<int>(part));
            }

            List<int> searchValues = new List<int>();

            HashSet<int> allValuesNoZeroes = new HashSet<int>(allValues);
            allValuesNoZeroes.Remove(0);

            HashSet<int> allValuesAndZero = new HashSet<int>(allValues);
            allValuesAndZero.Add(0);

            searchValues.AddRange(random.NextIntegersFrom(successSearches, new List<int>(allValuesNoZeroes)));
            searchValues.AddRange(random.NextIntegersExcluding(zeroSearches, allValuesAndZero));
            searchValues.AddRange(random.NextIntegersFrom(separatorSearches, separators));

            random.NextShuffle(searchValues);

            List<int> searchResults = new List<int>();
            foreach (int search in searchValues)
            {
                int result = 0;
                foreach (var part in parts)
                {
                    foreach (var value in part)
                    {
                        if (search == value)
                        {
                            result++;
                            break;
                        }
                    }
                }

                searchResults.Add(result);
            }

            List<int> unusedSeparators = new List<int>(separators);
            List<List<int>> partSeparators = new List<List<int>>();
            while (partSeparators.Count < parts.Count)
            {
                List<int> partSeparator = new List<int>();
                if (unusedSeparators.Count > 0)
                {
                    partSeparator.Add(unusedSeparators.PopLast());
                }
                partSeparators.Add(partSeparator);
            }

            while (unusedSeparators.Count > 0)
            {
                random.NextFrom(partSeparators).Add(unusedSeparators.PopLast());
            }

            List<int> message = parts.Zip(partSeparators).Flatten();

            List<string> inputLines = new List<string>();
            inputLines.Add(string.Join(" ", separators));
            inputLines.Add(string.Join(" ", message));
            inputLines.AddRange(searchValues.Select(s => s.ToString()));
            inputLines.Add("0");

            List<string> outputLines = new List<string>();
            outputLines.AddRange(searchResults.Select(s => s.ToString()));

            System.IO.File.WriteAllLines(name + ".in.txt", inputLines);
            System.IO.File.WriteAllLines(name + ".out.txt", outputLines);
        }
    }

    static class ListExtensions
    {
        public static List<T> Zip<T>(this List<T> thiz, List<T> other)
        {
            List<T> result = new List<T>();

            for (int i = 0; i < Math.Max(thiz.Count, other.Count); i++)
            {
                if (thiz.Count > i)
                {
                    result.Add(thiz[i]);
                }

                if (other.Count > i)
                {
                    result.Add(other[i]);
                }
            }

            return result;
        }

        public static List<T> Flatten<T>(this List<List<T>> list)
        {
            List<T> flat = new List<T>();

            foreach (var innerList in list)
            {
                flat.AddRange(innerList);
            }

            return flat;
        }

        public static T PopLast<T>(this List<T> list)
        {
            if (list.Count < 1)
            {
                throw new ArgumentException("list must be non-empty");
            }

            int lastIndex = list.Count - 1;

            T last = list[lastIndex];
            list.RemoveAt(lastIndex);

            return last;
        }
    }

    static class RandomExtensions
    {
        public static void NextShuffle<T>(this Random r, List<T> list)
        {
            for (int repeats = 0; repeats < 10; repeats++)
            {
                for (int i = 0; i < list.Count; i++)
                {
                    int otherInd = r.Next(0, list.Count);
                    var swap = list[i];
                    list[i] = list[otherInd];
                    list[otherInd] = swap;
                }
            }
        }

        public static int NextIndex<T>(this Random r, ICollection<T> range)
        {
            return r.Next(0, range.Count);
        }

        public static T NextFrom<T>(this Random r, List<T> from)
        {
            return from[NextIndex(r, from)];
        }

        public static List<int> NextIntegersFrom(this Random r, int count, List<int> from)
        {
            List<int> integers = new List<int>();

            while (integers.Count < count)
            {
                integers.Add(NextFrom(r, from));
            }

            return integers;
        }

        public static List<int> NextIntegers(this Random r, int count)
        {
            return NextIntegersExcluding(r, count, new HashSet<int>());
        }

        public static List<int> NextIntegersExcluding(this Random r, int count, HashSet<int> excluded)
        {
            List<int> integers = new List<int>();

            while (integers.Count < count)
            {
                integers.Add(NextExcluding(r, excluded));
            }

            return integers;
        }

        public static int NextExcluding(this Random r, HashSet<int> excluded)
        {
            int value = r.Next();
            while (excluded.Contains(value))
            {
                value = r.Next();
            }

            return value;
        }
    }
}
